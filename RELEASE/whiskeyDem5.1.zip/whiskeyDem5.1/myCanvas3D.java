/*
 * myCanvas3D.java
 */
 
import javax.media.j3d.Canvas3D;
import java.awt.*;


public class myCanvas3D extends Canvas3D {
  
  public myCanvas3D(GraphicsConfiguration config)
  {
    super(config);
  }

  /*
  public Dimension getPreferredSize()
  {
    //return new Dimension(700, 700);
    return new Dimension(ProgramConfig.getMainWindowWidth(), ProgramConfig.getMainWindowHeight());
  }
   */
  
}