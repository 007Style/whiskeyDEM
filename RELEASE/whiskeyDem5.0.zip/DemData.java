/*
 * DemData.java
 */

import javax.vecmath.*;


public class DemData extends Object {

  Point3f a[] = null;
  Point3f b[] = null;

  public DemData() {
  }

}