/*
 * PositionListener.java
 */
 

public interface PositionListener {
  public void positionChanged(PositionEvent posEvent);
}
